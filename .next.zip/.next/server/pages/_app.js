"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "@reduxjs/toolkit"
const toolkit_namespaceObject = require("@reduxjs/toolkit");
;// CONCATENATED MODULE: external "next-redux-wrapper"
const external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./store/api.js

const API = external_axios_default().create({
    baseURL: "https://admin.dpmhomes.com/api/"
});
/* harmony default export */ const api = (API);

// EXTERNAL MODULE: external "js-cookies"
var external_js_cookies_ = __webpack_require__(4240);
var external_js_cookies_default = /*#__PURE__*/__webpack_require__.n(external_js_cookies_);
;// CONCATENATED MODULE: ./store/api/authAPI.js


async function authLogin({ user , lang  }) {
    try {
        const res = await api.post(`/login?lang=${lang}`, {
            email: user.email,
            password: user.password
        });
        if (res.data.success) {
            external_js_cookies_default().setItem("userToken", res.data.data.token);
        }
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function createAccount({ user , lang  }) {
    try {
        const res = await api.post(`/register?lang=${lang}`, {
            name: user.name,
            email: user.email,
            phone: user.phone,
            password: user.password,
            type: user.type,
            account_status: user.account_status
        });
        if (res.data.success) {
            external_js_cookies_default().setItem("userToken", res.data.data.token);
        }
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function forgetPassword(email) {
    try {
        const res = await api.post("/forget-password", {
            email: email
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function resetPassword(data) {
    try {
        const res = await api.post("/reset-password", {
            email: data.email,
            token: data.code,
            new_password: data.password
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function getAuthInformation(userToken) {
    try {
        const res = await api.get("/get-info", {
            headers: {
                Authorization: `Bearer ${userToken}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function getMyProperties(userToken) {
    try {
        const res = await api.get("/my-properties", {
            headers: {
                Authorization: `Bearer ${userToken}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function userLogout(userToken) {
    try {
        const res = await api.get("/logout", {
            headers: {
                Authorization: `Bearer ${userToken}`
            }
        });
        external_js_cookies_default().removeItem("userToken");
        return await res.data;
    } catch (err) {
        return err;
    }
}

;// CONCATENATED MODULE: ./store/slices/auth.js



const initialState = {
    user: null,
    properties: []
};
const login = (0,toolkit_namespaceObject.createAsyncThunk)("auth/login", async (data)=>{
    const responseData = await authLogin(data);
    return responseData;
});
const getUserInfo = (0,toolkit_namespaceObject.createAsyncThunk)("auth/get-info", async (token)=>{
    const responseData = await getAuthInformation(token);
    return responseData;
});
const getUserProperties = (0,toolkit_namespaceObject.createAsyncThunk)("auth/get-my-properties", async (token)=>{
    const responseData = await getMyProperties(token);
    return responseData;
});
const sendForgetPasswordCode = (0,toolkit_namespaceObject.createAsyncThunk)("auth/forgetPassword", async (email)=>{
    const responseData = await forgetPassword(email);
    return responseData;
});
const changeMyPassword = (0,toolkit_namespaceObject.createAsyncThunk)("auth/resetPassword", async (data)=>{
    const responseData = await resetPassword(data);
    return responseData;
});
const register = (0,toolkit_namespaceObject.createAsyncThunk)("auth/register", async (data)=>{
    const responseData = await createAccount(data);
    return responseData;
});
const logout = (0,toolkit_namespaceObject.createAsyncThunk)("auth/logout", async (token)=>{
    const responseData = await userLogout(token);
    return responseData;
});
const authSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "auth",
    initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(login.fulfilled, (state, action)=>{
            state.user = action.payload;
        }).addCase(login.rejected, (state, action)=>{
            console.log(action.payload);
        }).addCase(register.fulfilled, (state, action)=>{
            state.user = action.payload;
        }).addCase(getUserInfo.fulfilled, (state, action)=>{
            state.user = action.payload;
        }).addCase(getUserProperties.fulfilled, (state, action)=>{
            state.properties = action.payload;
        }).addCase(sendForgetPasswordCode.fulfilled, (state, action)=>{
        // state.user = null;
        }).addCase(changeMyPassword.fulfilled, (state, action)=>{
        // state.user = null;
        }).addCase(logout.fulfilled, (state, action)=>{
            state.user = null;
        }).addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.auth,
                ...action.payload.auth
            };
            return nextState;
        });
    }
});
const selectUser = (state)=>state.auth.user
;
const selectUserProperties = (state)=>state.auth.properties
;
/* harmony default export */ const auth = (authSlice.reducer);

;// CONCATENATED MODULE: ./store/api/contactAPI.js


async function sendMessage(data) {
    try {
        const res = await api.post("/contact", {
            name: data.name,
            email: data.email,
            phone: data.phone,
            message: data.message
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}

;// CONCATENATED MODULE: ./store/slices/contact.js



const contact_initialState = {
    message: ""
};
const contactUs = (0,toolkit_namespaceObject.createAsyncThunk)("contact/contactUs", async (data)=>{
    const responseData = await sendMessage(data);
    return responseData;
});
const contactSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "contact",
    initialState: contact_initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(contactUs.fulfilled, (state, action)=>{
            state.message = action.payload.message;
        }).addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.contact,
                ...action.payload.contact
            };
            return nextState;
        });
    }
});
const selectContact = (state)=>state.contact
;
/* harmony default export */ const contact = (contactSlice.reducer);

;// CONCATENATED MODULE: ./store/api/propertiesAPI.js


async function getProperties({ type , userToken  }) {
    try {
        if (userToken) {
            const res = await api.get(`/get-property?type=${type}`, {
                headers: {
                    Authorization: `Bearer ${userToken}`
                }
            });
            return await res.data;
        } else {
            const res = await api.get(`/get-property?type=${type}`);
            return await res.data;
        }
    } catch (err) {
        return err;
    }
}
async function getPropertyById(id) {
    try {
        const res = await api.get(`/show-property?id=${id}`);
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addResidentialCashProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-residential-cash`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addResidentialInstallmentProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-residential-installment`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addResidentialBothProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-residential-both`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addResidentialRentProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-residential-rent`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addCommercialCashProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-commercial-cash`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addCommercialInstallmentProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-commercial-installment`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addCommercialBothProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-commercial-both`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addCommercialRentProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-commercial-rent`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addAdministrativeCashProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-administrative-cash`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addAdministrativeInstallmentProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-administrative-installment`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addAdministrativeBothProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-administrative-both`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function addAdministrativeRentProperty(data) {
    try {
        let token = external_js_cookies_default().getItem("userToken");
        const res = await api.post(`/add-administrative-rent`, {
            ...data,
            "images[]": data.images
        }, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}

;// CONCATENATED MODULE: ./store/slices/properties.js



const properties_initialState = {
    allProperties: [],
    property: {}
};
const getPropertiesWithTpye = (0,toolkit_namespaceObject.createAsyncThunk)("properties/getProperty", async ({ type , userToken  })=>{
    const responseData = await getProperties({
        type,
        userToken
    });
    return responseData;
});
const showProperty = (0,toolkit_namespaceObject.createAsyncThunk)("properties/showProperty", async (id)=>{
    const responseData = await getPropertyById(id);
    return responseData;
});
const addResidentialCash = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-residential-cash", async (data)=>{
    const responseData = await addResidentialCashProperty(data);
    return responseData;
});
const addResidentialInstallment = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-residential-installment", async (data)=>{
    const responseData = await addResidentialInstallmentProperty(data);
    return responseData;
});
const addResidentialBoth = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-residential-both", async (data)=>{
    const responseData = await addResidentialBothProperty(data);
    return responseData;
});
const addResidentialRent = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-residential-rent", async (data)=>{
    const responseData = await addResidentialRentProperty(data);
    return responseData;
});
const addCommercialCash = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-commercial-cash", async (data)=>{
    const responseData = await addCommercialCashProperty(data);
    return responseData;
});
const addCommercialInstallment = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-commercial-installment", async (data)=>{
    const responseData = await addCommercialInstallmentProperty(data);
    return responseData;
});
const addCommercialBoth = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-commercial-both", async (data)=>{
    const responseData = await addCommercialBothProperty(data);
    return responseData;
});
const addCommercialRent = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-commercial-rent", async (data)=>{
    const responseData = await addCommercialRentProperty(data);
    return responseData;
});
const addAdministrativeCash = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-administrative-cash", async (data)=>{
    const responseData = await addAdministrativeCashProperty(data);
    return responseData;
});
const addAdministrativeInstallment = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-administrative-installment", async (data)=>{
    const responseData = await addAdministrativeInstallmentProperty(data);
    return responseData;
});
const addAdministrativeBoth = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-administrative-both", async (data)=>{
    const responseData = await addAdministrativeBothProperty(data);
    return responseData;
});
const addAdministrativeRent = (0,toolkit_namespaceObject.createAsyncThunk)("properties/add-administrative-rent", async (data)=>{
    const responseData = await addAdministrativeRentProperty(data);
    return responseData;
});
const propertiesSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "properties",
    initialState: properties_initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getPropertiesWithTpye.fulfilled, (state, action)=>{
            state.allProperties = action.payload.data;
        }).addCase(showProperty.fulfilled, (state, action)=>{
            state.property = action.payload;
        }).addCase(addResidentialCash.fulfilled, (state, action)=>{}).addCase(addResidentialCash.rejected, (state, action)=>{}).addCase(addResidentialInstallment.fulfilled, (state, action)=>{}).addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.properties,
                ...action.payload.properties
            };
            return nextState;
        });
    }
});
const selectProperties = (state)=>state.properties
;
/* harmony default export */ const properties = (propertiesSlice.reducer);

;// CONCATENATED MODULE: ./store/api/countriesAPI.js

async function getCountries(lang) {
    try {
        const res = await api.get(`/get-countries?lang=${lang}`);
        return await res.data;
    } catch (err) {
        return err;
    }
}
async function getGovernorates(data) {
    try {
        const res = await api.get(`/get-governorates?country_id=${data.activeCountry}&lang=${data.locale ? data.locale : "en"}`);
        return await res.data;
    } catch (err) {
        return err;
    }
}

;// CONCATENATED MODULE: ./store/slices/countries.js



const countries_initialState = {
    countriesCounts: [],
    allCountries: [],
    allGovernorates: []
};
const getAllCountries = (0,toolkit_namespaceObject.createAsyncThunk)("countries/get-countries", async (lang)=>{
    const responseData = await getCountries(lang);
    return responseData;
});
const getAllGovernorates = (0,toolkit_namespaceObject.createAsyncThunk)("countries/get-governorates", async (data)=>{
    const responseData = await getGovernorates(data);
    return responseData;
});
const countriesSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "countries",
    initialState: countries_initialState,
    reducers: {
        getCountryItemsCount: (state, action)=>{
            state.countriesCounts = action.payload.allCountries.filter((item)=>{
                return item.country_id === item.country_id;
            });
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(getAllCountries.fulfilled, (state, action)=>{
            state.allCountries = action.payload.data;
        }).addCase(getAllGovernorates.fulfilled, (state, action)=>{
            state.allGovernorates = action.payload.data;
        }).addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.countries,
                ...action.payload.countries
            };
            return nextState;
        });
    }
});
const selectCountries = (state)=>state.countries
;
/* harmony default export */ const countries = (countriesSlice.reducer);

;// CONCATENATED MODULE: ./store/api/projectsAPI.js

async function getProjects() {
    try {
        const res = await api.get('/get-projects');
        return await res.data;
    } catch (err) {
        return err;
    }
}

;// CONCATENATED MODULE: ./store/slices/projects.js



const projects_initialState = {
    allProjects: []
};
const getAllProjects = (0,toolkit_namespaceObject.createAsyncThunk)("projects/getProjects", async ()=>{
    const responseData = await getProjects();
    return responseData;
});
const projectsSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "projects",
    initialState: projects_initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getAllProjects.fulfilled, (state, action)=>{
            state.allProjects = action.payload.data;
        }).addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.projects,
                ...action.payload.projects
            };
            return nextState;
        });
    }
});
const selectProjects = (state)=>state.projects
;
/* harmony default export */ const projects = (projectsSlice.reducer);

;// CONCATENATED MODULE: ./store/slices/filter.js


const filter_initialState = {
    activeCountry: null,
    activeGovernorate: null,
    activeSize: null,
    bedCount: null,
    propertyType: null,
    bathCount: null,
    filteredProperties: []
};
const filterSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "filter",
    initialState: filter_initialState,
    reducers: {
        setActiveCountry: (state, action)=>{
            state.activeCountry = action.payload;
        },
        setActiveGovernorate: (state, action)=>{
            state.activeGovernorate = action.payload;
        },
        setActiveSize: (state, action)=>{
            state.activeSize = action.payload;
        },
        setBedCount: (state, action)=>{
            state.bedCount = action.payload;
        },
        setBathCount: (state, action)=>{
            state.bathCount = action.payload;
        },
        setPropertyType: (state, action)=>{
            state.propertyType = action.payload;
        },
        filterByCountry: (state, action)=>{
            let allProperties = action.payload.allProperties, type = action.payload.type;
            if (type === "reset") {
                state.filteredProperties = allProperties;
                return;
            } else {
                state.filteredProperties = allProperties.filter((property)=>{
                    return Number(property.countryId) === Number(state.activeCountry);
                });
            }
        },
        filterByGovernorate: (state, action)=>{
            let allProperties = action.payload.allProperties, type = action.payload.type;
            if (type === "reset") {
                state.filteredProperties = allProperties;
                return;
            } else {
                state.filteredProperties = allProperties.filter((property)=>{
                    return Number(property.governorateId) === Number(state.activeGovernorate);
                });
            }
        },
        filterByPropertyType: (state, action)=>{
            console.log(action.payload);
            let allProperties = action.payload.allProperties, type = action.payload.type;
            if (type === "reset") {
                state.filteredProperties = allProperties;
                return;
            } else {
                state.filteredProperties = allProperties.filter((property)=>{
                    return property.property_type.toLowerCase() === state.propertyType.toLowerCase();
                });
            }
        },
        filterByAreaSize: (state, action)=>{
            let allProperties = action.payload.allProperties, type = action.payload.type;
            if (type === "reset") {
                state.filteredProperties = allProperties;
            } else {
                state.filteredProperties = allProperties.filter((property)=>{
                    return Number(state.activeSize) >= Number(property.total_area);
                });
            }
        },
        filterByBedNum: (state, action)=>{
            let allProperties = action.payload.allProperties, type = action.payload.type;
            if (type === "reset") {
                state.filteredProperties = allProperties;
            } else {
                state.filteredProperties = allProperties.filter((property)=>{
                    return Number(state.bedCount) >= Number(property.no_bed_room);
                });
            }
        },
        filterByBathNum: (state, action)=>{
            let allProperties = action.payload.allProperties, type = action.payload.type;
            if (type === "reset") {
                state.filteredProperties = allProperties;
            } else {
                state.filteredProperties = allProperties.filter((property)=>{
                    return Number(state.bathCount) >= Number(property.no_bath_room);
                });
            }
        },
        setFilteredProperties: (state, action)=>{
            state.filteredProperties = action.payload;
        },
        resetFilter: (state)=>{
            state.activeCountry = "", state.activeGovernorate = "", state.activeSize = "", state.bedCount = "", state.bathCount = "";
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.filter,
                ...action.payload.filter
            };
            return nextState;
        });
    }
});
const { setActiveCountry , setBedCount , setBathCount , setActiveGovernorate , filterByGovernorate , setActiveSize , filterByAreaSize , filterByCountry , setPropertyType , filterByPropertyType , filterByBedNum , filterByBathNum , setFilteredProperties , resetFilter ,  } = filterSlice.actions;
const selectFilter = (state)=>state.filter
;
/* harmony default export */ const filter = (filterSlice.reducer);

;// CONCATENATED MODULE: ./store/api/clientAPI.js

async function getClientDetails(id) {
    try {
        const res = await api.get(`/view-profile?id=${id}`);
        return await res.data;
    } catch (err) {
        return err;
    }
}

;// CONCATENATED MODULE: ./store/slices/client.js



const client_initialState = {
    clientData: ""
};
const getClientInfo = (0,toolkit_namespaceObject.createAsyncThunk)("client/getClientInfo", async (id)=>{
    const responseData = await getClientDetails(id);
    return responseData;
});
const clientSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "client",
    initialState: client_initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getClientInfo.fulfilled, (state, action)=>{
            state.clientData = action.payload;
        }).addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.client,
                ...action.payload.client
            };
            return nextState;
        });
    }
});
const selectClient = (state)=>state.client
;
/* harmony default export */ const client = (clientSlice.reducer);

;// CONCATENATED MODULE: ./store/api/wishlistAPI.js


async function updateWishlist(id) {
    try {
        const res = await api.get(`/update-wishlist?id=${id}`, {
            headers: {
                Authorization: `Bearer ${external_js_cookies_default().getItem("userToken")}`
            }
        });
        return await res.data;
    } catch (err) {
        return err;
    }
}

;// CONCATENATED MODULE: ./store/slices/wishlist.js



const wishlist_initialState = {};
const addPropertyToWishlist = (0,toolkit_namespaceObject.createAsyncThunk)("wishlist/update-wishlist", async (id)=>{
    const responseData = await updateWishlist(id);
    return responseData;
});
const wishlistSlice = (0,toolkit_namespaceObject.createSlice)({
    name: "wishlist",
    initialState: wishlist_initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(addPropertyToWishlist.fulfilled, (state, action)=>{}).addCase(external_next_redux_wrapper_namespaceObject.HYDRATE, (state, action)=>{
            const nextState = {
                ...state.wishlist,
                ...action.payload.wishlist
            };
            return nextState;
        });
    }
});
const selectWishlist = (state)=>state.wishlist
;
/* harmony default export */ const wishlist = (wishlistSlice.reducer);

;// CONCATENATED MODULE: ./store/index.js










const makeStore = ()=>(0,toolkit_namespaceObject.configureStore)({
        reducer: {
            auth: auth,
            contact: contact,
            properties: properties,
            countries: countries,
            projects: projects,
            filter: filter,
            client: client,
            wishlist: wishlist
        },
        devTools: true
    })
;
const wrapper = (0,external_next_redux_wrapper_namespaceObject.createWrapper)(makeStore);

;// CONCATENATED MODULE: external "react-toastify"
const external_react_toastify_namespaceObject = require("react-toastify");
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__(3126);
;// CONCATENATED MODULE: ./lang/ar.json
const ar_namespaceObject = JSON.parse('{"home":"الرئيسية","about-us":"من نحن","products":"المنتجات","contact-us":"اتصل بنا","join-us":"التوظيف","catering-services":"خدمات المطاعم","news-events":"الأخبار و الأحداث","find-a-store":"أقرب متجر","franchises":"الامتيازات","perfecting-your-way":"تحسين طريقك","brand-success":"نجاح العلامة التجارية","story-behind":"القصة وراء","loyalty-program":"برنامج الولاء","hiring":"التوظيف","fill-in-the-data-below":"املأ البيانات أدناه","please-fill-in-the-data-below-and-we-will-send-you":"يرجى ملء البيانات أدناه وسوف نرسل لك","name":"الأسم","email":"البريد الإلكتروني","phone":"الهاتف","country":"البلد","address":"العنوان","company":"الشركة","cv":"السيرة الذاتية","send":"إرسال","subscribe":"اشتراك","subscribe-to":"اشترك في نشرتنا الإخبارية","about-methods":"عن Methods","links-interset":"روابط مهمة","privacy":"الخصوصية","terms":"الشروط والأحكام","branches":"الفروع","copyright":"جميع الحقوق محفوظة لدي","time-line":"الجدول الزمني","methods-timeline":"الجدول الزمني لـ Methods","our-products":"منتجاتنا","just-a-taste-with-methods-menu":"مجرد لمحة عن قائمة Methods","photo":"صور","video":"فيديوهات","read-more":"اقرأ المزيد","about-the-city":"عن المدينة","partners":"شركائنا","our-strategic-partners":"شركاؤنا الاستراتيجيون","latest-photos":"أحدث الصور","inquiries":"استفسارات","for-all-inquiries":"لكل استفسارات...","inquiries-description":"تواصل معنا من خلال زيارة مقر الشركة أو عبر البريد الإلكتروني الرسمي للعلامة التجارية (أنجو)"}');
;// CONCATENATED MODULE: ./lang/en.json
const en_namespaceObject = JSON.parse('{"home":"Home Page","about-us":"About Us","products":"Products","contact-us":"Contact Us","join-us":"Join Us","catering-services":"Catering Services","news-events":"News & Events","find-a-store":"Find a Store","franchises":"Franchises","perfecting-your-way":"Perfecting Your Way","brand-success":"Brand Success","story-behind":"Story Behind","loyalty-program":"Loyalty Program","hiring":"Hiring","fill-in-the-data-below":"Fill in the Data Below","please-fill-in-the-data-below-and-we-will-send-you":"Please fill in the data below and we will send you","name":"Name","email":"Email","phone":"Phone","country":"Country","address":"Address","company":"Company","cv":"CV","send":"Send","subscribe":"Subscribe","subscribe-to":"Subscribe to Our Newsletter","about-methods":"About Methods","links-interset":"Interesting Links","privacy":"Privacy","terms":"Terms","branches":"Branches","copyright":"All rights reserved For","time-line":"Timeline","methods-timeline":"Methods Timeline","our-products":"Our Products","just-a-taste-with-methods-menu":"Just a Taste with Methods Menu","photo":"Photo","video":"Video","read-more":"Read More","about-the-city":"About the City","partners":"Partners","our-strategic-partners":"Our Strategic Partners","latest-photos":"Latest photos","inquiries":"Inquiries","for-all-inquiries":"For Any Inquiries...","inquiries-description":"Contact us by visiting the company\'s headquarters or through the official e-mail of the brand (Ango)"}');
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "aos"
var external_aos_ = __webpack_require__(9783);
var external_aos_default = /*#__PURE__*/__webpack_require__.n(external_aos_);
;// CONCATENATED MODULE: ./pages/_app.js















const messages = {
    ar: ar_namespaceObject,
    en: en_namespaceObject
};
function MyApp({ Component , pageProps  }) {
    const { locale , defaultLocale  } = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        let html = document.querySelector("html");
        html.setAttribute("dir", locale === 'ar' ? 'rtl' : 'ltr');
        external_aos_default().init({
            duration: 1000,
            easing: "ease-in-out"
        });
    }, [
        locale
    ]);
    (0,external_react_.useEffect)(()=>{
        let progressBar = document.querySelector(".progress-wrap");
        if (progressBar) {
            scrollToTop();
        }
        navigator.geolocation.getCurrentPosition(function(position) {
            console.log(position);
        });
    }, []);
    const { 0: showNotification , 1: setShowNotification  } = (0,external_react_.useState)(true);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "description",
                    content: locale === "en" ? "" : ""
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.IntlProvider, {
                locale: locale,
                messages: messages[locale],
                defaultLocale: defaultLocale,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_toastify_namespaceObject.ToastContainer, {})
        ]
    }));
}
/* harmony default export */ const _app = (wrapper.withRedux(MyApp));


/***/ }),

/***/ 9783:
/***/ ((module) => {

module.exports = require("aos");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4240:
/***/ ((module) => {

module.exports = require("js-cookies");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3126:
/***/ ((module) => {

module.exports = require("react-intl");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9033));
module.exports = __webpack_exports__;

})();