"use strict";
(() => {
var exports = {};
exports.id = 160;
exports.ids = [160];
exports.modules = {

/***/ 8652:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ franchises),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: external "react-bootstrap/Accordion"
const Accordion_namespaceObject = require("react-bootstrap/Accordion");
var Accordion_default = /*#__PURE__*/__webpack_require__.n(Accordion_namespaceObject);
;// CONCATENATED MODULE: ./public/img/2021-01-21 (1).png
/* harmony default export */ const _2021_01_21_1_ = ({"src":"/_next/static/media/2021-01-21 (1).a3ba8b74.png","height":345,"width":320,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAIAAAC6ZnJRAAAAu0lEQVR42gGwAE//ALalm66dk6GLeoBtX5N/cKaQf5+KewDJtqasl4afjH6SfGuPgHmVf3GijHsA897L4cWu2rmcy6R2poJioYt7taedAMesn6WRhb+kjsa2qrOgkaaXi6yhmwCIj1WemIehkojHwsCPkZeajIeroJsAcI0oUmkdAAAAAAAYP05ZWGJoa3mHAC9XFoWLT6uVdrqKgcOUjqd1c5pxfgCFelSZl16vmoDPw7/o39/u3d7s1NTfyF5eKaTHkwAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./components/navbar.jsx
var navbar = __webpack_require__(8907);
// EXTERNAL MODULE: ./components/footer.jsx
var footer = __webpack_require__(7524);
// EXTERNAL MODULE: ./common/axios.js
var axios = __webpack_require__(5115);
// EXTERNAL MODULE: external "aos"
var external_aos_ = __webpack_require__(9783);
var external_aos_default = /*#__PURE__*/__webpack_require__.n(external_aos_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__(3126);
;// CONCATENATED MODULE: ./pages/franchises/index.jsx











"use client";
const page = ({ data  })=>{
    let { 0: email , 1: setEmail  } = (0,external_react_.useState)("");
    let { 0: name , 1: setName  } = (0,external_react_.useState)("");
    let { 0: phone , 1: setPhone  } = (0,external_react_.useState)("");
    let { 0: address , 1: setAddress  } = (0,external_react_.useState)("");
    let { 0: country , 1: setCountry  } = (0,external_react_.useState)("");
    const SendFranchiseRequest = async (e)=>{
        e.preventDefault();
        await axios/* default.post */.Z.post("https://methods-backend.puiux.org/api/forms/franchise-request", {
            email,
            name,
            phone,
            address,
            country
        }, {
            headers: {
                "Accept-Language": "ar"
            }
        }).then((res)=>{}).catch((err)=>{
            console.log(err);
        });
    };
    let { franchisesOverview , franchisesApplyContent , settings , franchisesModels ,  } = data;
    (0,external_react_.useEffect)(()=>{
        external_aos_default().init({
            duration: 1000,
            easing: "ease-in-out"
        });
    }, []);
    const sliderSettings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            classNameName: "slick-prev",
            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                className: "fa-solid fa-arrow-right"
            })
        }),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            classNameName: "slick-next",
            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                className: "fa-solid fa-arrow-left"
            })
        })
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "home",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "back_home",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(navbar/* default */.Z, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "position-relative home_3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "logo_home ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            "data-aos": "fade-down",
                                            "data-aos-delay": "100",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "./img/Group 5733.png",
                                                alt: "",
                                                loading: "lazy"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "d-flex align-items-center writeit justify-content-center mt-2",
                                            "data-aos-delay": "100",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
                                                id: "perfecting-your-way"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h__img",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "./img/DSC-2.png",
                                        alt: "",
                                        className: "w-100 home_img",
                                        loading: "lazy"
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: franchisesOverview
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                        className: "caros11_text",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                        children: "FRANCHISE MODELS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: "Franchise Models"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "caros ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                                    ...sliderSettings,
                                    children: franchisesModels.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "card-content-caros",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "./img/coffee-beans.png",
                                                    alt: `${item.title} image`,
                                                    loading: "lazy"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h6", {
                                                    children: [
                                                        item.title,
                                                        ") "
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: item.description
                                                })
                                            ]
                                        }, item.id)
                                    )
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                        className: "row accordion_div about align-items-center flex_direction_column mt-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-md-6 col-sm-12 about_right",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        "data-aos": "fade-right",
                                        "data-aos-delay": "0",
                                        className: "font-reto color-p-FAQ",
                                        children: "APPLY FOR FRANCHISE"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        "data-aos": "fade-right",
                                        "data-aos-delay": "100",
                                        children: "FAQ(Frequent Asked Questions)"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        "data-aos": "fade-right",
                                        "data-aos-delay": "200",
                                        children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown ."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-md-6 col-sm-12 d-flex justify-content-end align-items-center accordion_div_right",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Accordion_default()), {
                                    defaultActiveKey: [
                                        "0"
                                    ],
                                    alwaysOpen: true,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Accordion_default()).Item, {
                                            eventKey: "0",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Header, {
                                                    children: "What is method?"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Body, {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Accordion_default()).Item, {
                                            eventKey: "1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Header, {
                                                    children: "What is method?"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Body, {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Accordion_default()).Item, {
                                            eventKey: "2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Header, {
                                                    children: "What is method?"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Body, {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Accordion_default()).Item, {
                                            eventKey: "3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Header, {
                                                    children: "What is method?"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Accordion_default()).Body, {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: franchisesApplyContent
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                        className: "about join_col row align-items-center ",
                        "data-aos": "fade-right",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-sm-12 col-md-6 card_join",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
                                            id: "fill-in-the-data-below"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "pb-4 pt-2 ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
                                            id: "please-fill-in-the-data-below-and-we-will-send-you"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                        id: "join-us-form",
                                        onSubmit: (e)=>SendFranchiseRequest(e)
                                        ,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "login_card",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "wave-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            required: "",
                                                            type: "text",
                                                            id: "name",
                                                            className: "input",
                                                            value: name,
                                                            onChange: (e)=>setName(e.target.value)
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "bar"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            className: "label",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa-solid fa-user label-char"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 0
                                                                    },
                                                                    children: "N"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 1
                                                                    },
                                                                    children: "a"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 2
                                                                    },
                                                                    children: "m"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 3
                                                                    },
                                                                    children: "e"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "wave-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            required: "",
                                                            type: "email",
                                                            id: "email",
                                                            value: email,
                                                            onChange: (e)=>setEmail(e.target.value)
                                                            ,
                                                            className: "input"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "bar"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            className: "label",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa-solid fa-envelope label-char"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 0
                                                                    },
                                                                    children: "E"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 1
                                                                    },
                                                                    children: "m"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 2
                                                                    },
                                                                    children: "a"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 3
                                                                    },
                                                                    children: "i"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 4
                                                                    },
                                                                    children: "l"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "wave-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            required: "",
                                                            type: "text",
                                                            value: phone,
                                                            onChange: (e)=>setPhone(e.target.value)
                                                            ,
                                                            id: "phone",
                                                            className: "input"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "bar"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            className: "label",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa-solid fa-phone label-char"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 0
                                                                    },
                                                                    children: "P"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 1
                                                                    },
                                                                    children: "h"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 2
                                                                    },
                                                                    children: "o"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 3
                                                                    },
                                                                    children: "n"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 4
                                                                    },
                                                                    children: "e"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char m_n",
                                                                    style: {
                                                                        "--index": 5
                                                                    },
                                                                    children: "n"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 6
                                                                    },
                                                                    children: "u"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 7
                                                                    },
                                                                    children: "m"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 8
                                                                    },
                                                                    children: "p"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 9
                                                                    },
                                                                    children: "e"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 10
                                                                    },
                                                                    children: "r"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "wave-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            value: country,
                                                            onChange: (e)=>setCountry(e.target.value)
                                                            ,
                                                            required: "",
                                                            type: "text",
                                                            id: "country",
                                                            className: "input"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "bar"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            className: "label",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa-solid fa-earth-americas label-char"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 0
                                                                    },
                                                                    children: "C"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 1
                                                                    },
                                                                    children: "o"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 2
                                                                    },
                                                                    children: "n"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 3
                                                                    },
                                                                    children: "t"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 4
                                                                    },
                                                                    children: "r"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 5
                                                                    },
                                                                    children: "y"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "wave-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            required: "",
                                                            value: address,
                                                            onChange: (e)=>setAddress(e.target.value)
                                                            ,
                                                            type: "text",
                                                            id: "address",
                                                            className: "input"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "bar"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            className: "label",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa-solid fa-location-dot label-char"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 0
                                                                    },
                                                                    children: "A"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 1
                                                                    },
                                                                    children: "d"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 2
                                                                    },
                                                                    children: "d"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 3
                                                                    },
                                                                    children: "r"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 4
                                                                    },
                                                                    children: "e"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "label-char",
                                                                    style: {
                                                                        "--index": 5
                                                                    },
                                                                    children: "s"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "submit",
                                                    name: "",
                                                    id: "join-us-btn",
                                                    className: "btm_send",
                                                    children: "Send"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-sm-12 col-md-6 join_right p-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                        "data-aos-delay": "0",
                                        className: "font-reto",
                                        children: "INQUIRIES"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        "data-aos-delay": "100",
                                        children: "For Any Inquiries..."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        "data-aos-delay": "200",
                                        children: "Contact us by visiting the company's headquarters or through the official e-mail of the brand (Ango)"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "d-flex align-items-center icon_social pt-3",
                                        children: [
                                            (settings === null || settings === void 0 ? void 0 : settings.instagram) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: settings.instagram,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fa-brands fa-instagram",
                                                    "data-aos": "fade-up",
                                                    "data-aos-delay": "200"
                                                })
                                            }),
                                            (settings === null || settings === void 0 ? void 0 : settings.tiktok) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "#",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fa-brands fa-tiktok",
                                                    "data-aos": "fade-up",
                                                    "data-aos-delay": "0"
                                                })
                                            }),
                                            (settings === null || settings === void 0 ? void 0 : settings.whatsapp) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "#",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fa-brands fa-whatsapp",
                                                    "data-aos": "fade-up",
                                                    "data-aos-delay": "100"
                                                })
                                            }),
                                            (settings === null || settings === void 0 ? void 0 : settings.twitter) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "#",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fa-brands fa-twitter",
                                                    "data-aos": "fade-up",
                                                    "data-aos-delay": "300"
                                                })
                                            }),
                                            (settings === null || settings === void 0 ? void 0 : settings.email) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "#",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fa-solid fa-envelope",
                                                    "data-aos": "fade-up",
                                                    "data-aos-delay": "300"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    }));
};
/* harmony default export */ const franchises = (page);
async function getServerSideProps() {
    try {
        var ref, ref1, ref2, ref3, ref4, ref5;
        const franchisesOverview = await axios/* default.get */.Z.get("/core/page/franchises-overview");
        const franchisesModels = await axios/* default.get */.Z.get("/core/franchise-models");
        const franchisesApplyContent = await axios/* default.get */.Z.get("/core/page/franchises-apply-content");
        const settings = await axios/* default.get */.Z.get("/core/settings");
        return {
            props: {
                data: {
                    franchisesOverview: franchisesOverview === null || franchisesOverview === void 0 ? void 0 : (ref = franchisesOverview.data) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.html,
                    franchisesApplyContent: franchisesApplyContent === null || franchisesApplyContent === void 0 ? void 0 : (ref2 = franchisesApplyContent.data) === null || ref2 === void 0 ? void 0 : (ref3 = ref2.data) === null || ref3 === void 0 ? void 0 : ref3.html,
                    franchisesModels: franchisesModels === null || franchisesModels === void 0 ? void 0 : (ref4 = franchisesModels.data) === null || ref4 === void 0 ? void 0 : ref4.data,
                    settings: settings === null || settings === void 0 ? void 0 : (ref5 = settings.data) === null || ref5 === void 0 ? void 0 : ref5.data
                }
            }
        };
    } catch (err) {
        console.log("err", err);
        return {
            props: {
                error: err.message
            }
        };
    }
}


/***/ }),

/***/ 9783:
/***/ ((module) => {

module.exports = require("aos");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4240:
/***/ ((module) => {

module.exports = require("js-cookies");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 9306:
/***/ ((module) => {

module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 3126:
/***/ ((module) => {

module.exports = require("react-intl");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,29], () => (__webpack_exec__(8652)));
module.exports = __webpack_exports__;

})();