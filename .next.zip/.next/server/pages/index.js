"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 4636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: external "aos"
var external_aos_ = __webpack_require__(9783);
var external_aos_default = /*#__PURE__*/__webpack_require__.n(external_aos_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/footer.jsx
var footer = __webpack_require__(7524);
;// CONCATENATED MODULE: ./layouts/default.jsx




function getDirection(locale) {
    return locale === "ar" ? "rtl" : "ltr";
}
const Default = ({ children , pageName , className  })=>{
    const { locale  } = (0,router_.useRouter)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${getDirection(locale)} ${className}`,
        dir: getDirection(locale),
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    }));
};
/* harmony default export */ const layouts_default = (Default);

// EXTERNAL MODULE: ./components/navbar.jsx
var navbar = __webpack_require__(8907);
// EXTERNAL MODULE: ./common/axios.js
var axios = __webpack_require__(5115);
;// CONCATENATED MODULE: ./pages/index.jsx









const HomePage = ({ data  })=>{
    const { 0: activeTab , 1: setActiveTab  } = (0,external_react_.useState)("photo");
    (0,external_react_.useEffect)(()=>{
        external_aos_default().init({
            duration: 1000,
            easing: "ease-in-out"
        });
    }, []);
    let { banner , about , services , partners , dynamicProducts , productsInfo , statistics , timeLine , newsPhoto , newsVideo ,  } = data;
    const settings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 3,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            classNameName: "slick-prev",
            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                className: "fa-solid fa-arrow-right"
            })
        }),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            classNameName: "slick-next",
            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                className: "fa-solid fa-arrow-left"
            })
        })
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layouts_default, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                    className: "home",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(navbar/* default */.Z, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: banner
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: about
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    dangerouslySetInnerHTML: {
                        __html: timeLine
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: statistics
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "./img/logo-methods-back.png",
                            alt: "",
                            className: "logo-methods-back"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: productsInfo
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("section", {
                            className: "caros mt-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                                ...settings,
                                children: dynamicProducts.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: `/products/${item.id}`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    "data-aos": "fade-up",
                                                    "data-aos-delay": "700",
                                                    className: "product-card-content",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: item.thumbnail,
                                                            alt: `${item.title} image`,
                                                            loading: "lazy"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                            children: item.title
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            children: item.description
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    }, item.id)
                                )
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: services
                            }
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "news position-relative",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "text-center our_productsp font-reto",
                                    children: "NEWS AND EVENTS"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    children: "News & Events"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "nav nav-tabs nav__tabs",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: ()=>setActiveTab("photo")
                                                ,
                                                className: `nav-link ${activeTab === "photo" ? "active" : ""}`,
                                                type: "button",
                                                children: "Photo"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: ()=>setActiveTab("video")
                                                ,
                                                className: `nav-link ${activeTab === "video" ? "active" : ""}`,
                                                type: "button",
                                                children: "Video"
                                            })
                                        })
                                    ]
                                }),
                                activeTab === "photo" && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `tab-content`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "row justify-content-center gap",
                                        children: newsPhoto.slice(0, 5).map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: `col-md-${index === 0 || 1 ? "4 hv" : 0}  col-sm-12 hover01 news_img_padding`,
                                                "data-aos": index === 0 || 1 ? "fade-up" : 0,
                                                "data-aos-delay": index === 0 ? 100 : index === 1 ? 200 : "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: `/news-events/${item.id}`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: "./img/waffles-with-chocolate-sauce-wooden-plate.png",
                                                            alt: "",
                                                            loading: "lazy"
                                                        })
                                                    })
                                                })
                                            }, item.id)
                                        )
                                    })
                                }),
                                activeTab === "video" && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `tab-content`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "row justify-content-center pb-3 gap",
                                        children: newsVideo.slice(0, 5).map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: `col-md-${item === 0 || 1 ? "6" : 0} news_img_padding col-sm-12 position-relative hv hover01`,
                                                "data-aos": `${index === 0 || 2 || 0 ? "fade-right" : 0}`,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "position-relative",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                        src: "./img/DSC05559.png",
                                                                        alt: ""
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "promo-video",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "waves-block",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                className: "waves wave-1"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                className: "waves wave-2"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                className: "waves wave-3"
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("section", {
                                                        className: "di_img position-absolute",
                                                        id: "di_img",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                                    children: item.title
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: item.meta_description
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        )
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/news-events",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                            "data-aos": "zoom-in",
                                            className: "font-reto",
                                            children: [
                                                "READ More",
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fa-solid fa-arrow-right"
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "./img/resha2.png",
                            alt: "",
                            className: "position-absolute end-0 resha2",
                            loading: "lazy"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    dangerouslySetInnerHTML: {
                        __html: partners
                    }
                })
            ]
        })
    }));
};
/* harmony default export */ const pages = (HomePage);
async function getServerSideProps() {
    try {
        var ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, ref10, ref11, ref12, ref13, ref14, ref15, ref16, ref17, ref18, ref19;
        const banner = await axios/* default.get */.Z.get("/core/page/home-banner");
        const about = await axios/* default.get */.Z.get("/core/page/home-about");
        const timeLine = await axios/* default.get */.Z.get("/core/page/home-time-line");
        const statistics = await axios/* default.get */.Z.get("/core/page/home-statistics");
        const productsInfo = await axios/* default.get */.Z.get("/core/page/home-our-products");
        const dynamicProducts = await axios/* default.get */.Z.get("/products?per_page=10");
        const newsVideo = await axios/* default.get */.Z.get("/news?type=video&per_page=10");
        const newsPhoto = await axios/* default.get */.Z.get("/news?type=photo&per_page=10");
        const services = await axios/* default.get */.Z.get("/core/page/home-our-services");
        const partners = await axios/* default.get */.Z.get("/core/page/home-partners");
        return {
            props: {
                data: {
                    banner: banner === null || banner === void 0 ? void 0 : (ref = banner.data) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.html,
                    about: about === null || about === void 0 ? void 0 : (ref2 = about.data) === null || ref2 === void 0 ? void 0 : (ref3 = ref2.data) === null || ref3 === void 0 ? void 0 : ref3.html,
                    timeLine: timeLine === null || timeLine === void 0 ? void 0 : (ref4 = timeLine.data) === null || ref4 === void 0 ? void 0 : (ref5 = ref4.data) === null || ref5 === void 0 ? void 0 : ref5.html,
                    statistics: statistics === null || statistics === void 0 ? void 0 : (ref6 = statistics.data) === null || ref6 === void 0 ? void 0 : (ref7 = ref6.data) === null || ref7 === void 0 ? void 0 : ref7.html,
                    productsInfo: productsInfo === null || productsInfo === void 0 ? void 0 : (ref8 = productsInfo.data) === null || ref8 === void 0 ? void 0 : (ref9 = ref8.data) === null || ref9 === void 0 ? void 0 : ref9.html,
                    dynamicProducts: dynamicProducts === null || dynamicProducts === void 0 ? void 0 : (ref10 = dynamicProducts.data) === null || ref10 === void 0 ? void 0 : (ref11 = ref10.data) === null || ref11 === void 0 ? void 0 : ref11.items,
                    newsPhoto: newsPhoto === null || newsPhoto === void 0 ? void 0 : (ref12 = newsPhoto.data) === null || ref12 === void 0 ? void 0 : (ref13 = ref12.data) === null || ref13 === void 0 ? void 0 : ref13.items,
                    newsVideo: newsVideo === null || newsVideo === void 0 ? void 0 : (ref14 = newsVideo.data) === null || ref14 === void 0 ? void 0 : (ref15 = ref14.data) === null || ref15 === void 0 ? void 0 : ref15.items,
                    services: services === null || services === void 0 ? void 0 : (ref16 = services.data) === null || ref16 === void 0 ? void 0 : (ref17 = ref16.data) === null || ref17 === void 0 ? void 0 : ref17.html,
                    partners: partners === null || partners === void 0 ? void 0 : (ref18 = partners.data) === null || ref18 === void 0 ? void 0 : (ref19 = ref18.data) === null || ref19 === void 0 ? void 0 : ref19.html
                }
            }
        };
    } catch (err) {
        console.log("err", err);
        return {
            props: {
                error: err.message
            }
        };
    }
}


/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 9783:
/***/ ((module) => {

module.exports = require("aos");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4240:
/***/ ((module) => {

module.exports = require("js-cookies");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 9306:
/***/ ((module) => {

module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 3126:
/***/ ((module) => {

module.exports = require("react-intl");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,29], () => (__webpack_exec__(4636)));
module.exports = __webpack_exports__;

})();