"use strict";
(() => {
var exports = {};
exports.id = 909;
exports.ids = [909];
exports.modules = {

/***/ 8610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ hiring),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "aos"
var external_aos_ = __webpack_require__(9783);
var external_aos_default = /*#__PURE__*/__webpack_require__.n(external_aos_);
// EXTERNAL MODULE: ./common/axios.js
var axios = __webpack_require__(5115);
;// CONCATENATED MODULE: ./Components/form-join-us.js




const FormJoinUs = ()=>{
    let { 0: email , 1: setEmail  } = (0,external_react_.useState)("");
    let { 0: name , 1: setName  } = (0,external_react_.useState)("");
    let { 0: phone , 1: setPhone  } = (0,external_react_.useState)("");
    let { 0: address , 1: setAddress  } = (0,external_react_.useState)("");
    let { 0: country , 1: setCountry  } = (0,external_react_.useState)("");
    let { 0: cv , 1: setCv  } = (0,external_react_.useState)("");
    const SendJobRequest = async (e)=>{
        e.preventDefault();
        await axios/* default.post */.Z.post("https://methods-backend.puiux.org/api/forms/join-us", {
            email,
            name,
            phone,
            address,
            country
        }, {
            headers: {
                "Accept-Language": "ar"
            }
        }).then((res)=>{}).catch((err)=>{
            console.log(err);
        });
    };
    (0,external_react_.useEffect)(()=>{
        external_aos_default().init({
            duration: 1000,
            easing: "ease-in-out"
        });
    }, []);
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("form", {
            action: "",
            id: "join-us-form",
            onSubmit: (e)=>SendJobRequest(e)
            ,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "login_card",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "wave-group",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                required: "",
                                type: "text",
                                id: "name",
                                value: name,
                                onChange: (e)=>setName(e.target.value)
                                ,
                                className: "input"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bar"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "label",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-solid fa-user label-char"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 0
                                        },
                                        children: "N"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 1
                                        },
                                        children: "a"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 2
                                        },
                                        children: "m"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 3
                                        },
                                        children: "e"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "wave-group",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                required: "",
                                type: "email",
                                onChange: (e)=>setEmail(e.target.value)
                                ,
                                value: email,
                                id: "email",
                                className: "input"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bar"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "label",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-solid fa-envelope label-char"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 0
                                        },
                                        children: "E"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 1
                                        },
                                        children: "m"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 2
                                        },
                                        children: "a"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 3
                                        },
                                        children: "i"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 4
                                        },
                                        children: "l"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "wave-group",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                required: "",
                                type: "text",
                                value: phone,
                                onChange: (e)=>setPhone(e.target.value)
                                ,
                                id: "phone",
                                className: "input"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bar"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "label",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-solid fa-phone label-char"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 0
                                        },
                                        children: "P"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 1
                                        },
                                        children: "h"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 2
                                        },
                                        children: "o"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 3
                                        },
                                        children: "n"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 4
                                        },
                                        children: "e"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char m_n",
                                        style: {
                                            "--index": 5
                                        },
                                        children: "n"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 6
                                        },
                                        children: "u"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 7
                                        },
                                        children: "m"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 8
                                        },
                                        children: "p"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 9
                                        },
                                        children: "e"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 10
                                        },
                                        children: "r"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "wave-group",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                required: "",
                                type: "text",
                                id: "country",
                                value: country,
                                onChange: (e)=>setCountry(e.target.value)
                                ,
                                className: "input"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bar"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "label",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-solid fa-earth-americas label-char"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 0
                                        },
                                        children: "C"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 1
                                        },
                                        children: "o"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 2
                                        },
                                        children: "n"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 3
                                        },
                                        children: "t"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 4
                                        },
                                        children: "r"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 5
                                        },
                                        children: "y"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "wave-group",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                required: "",
                                type: "text",
                                id: "address",
                                value: address,
                                onChange: (e)=>setAddress(e.target.value)
                                ,
                                className: "input"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bar"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "label",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-solid fa-location-dot label-char"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 0
                                        },
                                        children: "A"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 1
                                        },
                                        children: "d"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 2
                                        },
                                        children: "d"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 3
                                        },
                                        children: "r"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 4
                                        },
                                        children: "e"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "label-char",
                                        style: {
                                            "--index": 5
                                        },
                                        children: "s"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "drop-zone pt-4 pb-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "./img/cv.png",
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex pt-4 justify-content-around align-items-center w-100",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "drop-zone__prompt",
                                        children: "UPLOAD YOUR CV HERE"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-solid fa-arrow-up-from-bracket"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "file",
                                name: "myFile",
                                id: "upload-files",
                                onChange: async (e)=>{
                                    const file = e.target.files[0];
                                    const reader = new FileReader();
                                    reader.onload = ()=>{
                                        setCv(reader.result);
                                    };
                                    reader.readAsArrayBuffer(file);
                                },
                                className: "drop-zone__input"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        type: "submit",
                        name: "",
                        id: "join-us-btn",
                        className: "btm_send",
                        children: "Send"
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const form_join_us = (FormJoinUs);

// EXTERNAL MODULE: ./components/navbar.jsx
var navbar = __webpack_require__(8907);
// EXTERNAL MODULE: ./components/footer.jsx
var footer = __webpack_require__(7524);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__(3126);
;// CONCATENATED MODULE: ./pages/hiring/index.jsx









"use client";
const page = ({ data  })=>{
    let { joinUs , settings  } = data;
    console.log(settings);
    (0,external_react_.useEffect)(()=>{
        external_aos_default().init({
            duration: 1000,
            easing: "ease-in-out"
        });
    }, []);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "home",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "back_home",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(navbar/* default */.Z, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "position-relative home_3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "logo_home ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            "data-aos": "fade-down",
                                            "data-aos-delay": "100",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "./img/Group 5733.png",
                                                alt: "",
                                                loading: "lazy"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "d-flex align-items-center writeit justify-content-center mt-2",
                                            "data-aos": "fade-up",
                                            "data-aos-delay": "100",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
                                                id: "perfecting-your-way"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h__img",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "./img/DSC-2.png",
                                        alt: "",
                                        className: "w-100 home_img",
                                        loading: "lazy"
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "join",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: joinUs
                            }
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                            className: "about join_col row align-items-center ",
                            "data-aos": "fade-right",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-sm-12 col-md-6 card_join",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
                                                id: "fill-in-the-data-below"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "pb-4 pt-2 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
                                                id: "please-fill-in-the-data-below-and-we-will-send-you"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(form_join_us, {})
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-sm-12 col-md-6 join_right p-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            "data-aos": "fade-up",
                                            "data-aos-delay": "0",
                                            className: "font-reto",
                                            children: "INQUIRIES"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            "data-aos": "fade-up",
                                            "data-aos-delay": "100",
                                            children: "For Any Inquiries..."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            "data-aos": "fade-up",
                                            "data-aos-delay": "200",
                                            children: "Contact us by visiting the company's headquarters or through the official e-mail of the brand (Ango)"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "d-flex align-items-center icon_social pt-3",
                                            children: [
                                                (settings === null || settings === void 0 ? void 0 : settings.instagram) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: settings.instagram,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-brands fa-instagram",
                                                        "data-aos": "fade-up",
                                                        "data-aos-delay": "200"
                                                    })
                                                }),
                                                (settings === null || settings === void 0 ? void 0 : settings.tiktok) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-brands fa-tiktok",
                                                        "data-aos": "fade-up",
                                                        "data-aos-delay": "0"
                                                    })
                                                }),
                                                (settings === null || settings === void 0 ? void 0 : settings.whatsapp) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-brands fa-whatsapp",
                                                        "data-aos": "fade-up",
                                                        "data-aos-delay": "100"
                                                    })
                                                }),
                                                (settings === null || settings === void 0 ? void 0 : settings.twitter) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-brands fa-twitter",
                                                        "data-aos": "fade-up",
                                                        "data-aos-delay": "300"
                                                    })
                                                }),
                                                (settings === null || settings === void 0 ? void 0 : settings.email) && /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-solid fa-envelope",
                                                        "data-aos": "fade-up",
                                                        "data-aos-delay": "300"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    }));
};
/* harmony default export */ const hiring = (page);
async function getServerSideProps() {
    try {
        var ref, ref1, ref2;
        const joinUs = await axios/* default.get */.Z.get("/core/page/join-us");
        const settings = await axios/* default.get */.Z.get("/core/settings");
        return {
            props: {
                data: {
                    joinUs: joinUs === null || joinUs === void 0 ? void 0 : (ref = joinUs.data) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.html,
                    settings: settings === null || settings === void 0 ? void 0 : (ref2 = settings.data) === null || ref2 === void 0 ? void 0 : ref2.data
                }
            }
        };
    } catch (err) {
        console.log("err", err);
        return {
            props: {
                error: err.message
            }
        };
    }
}


/***/ }),

/***/ 9783:
/***/ ((module) => {

module.exports = require("aos");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4240:
/***/ ((module) => {

module.exports = require("js-cookies");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 9306:
/***/ ((module) => {

module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 3126:
/***/ ((module) => {

module.exports = require("react-intl");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,29], () => (__webpack_exec__(8610)));
module.exports = __webpack_exports__;

})();